Summary
-------

The zip archive was downloaded from SAS Institute (http://www.sas.com)
from the Maps Online site (https://support.sas.com/en/knowledge-base/maps-geocoding/maps-online.html)
and is used to replace the exising Zipcode data set in the Sashelp library.

Note: You MUST have write access to the Sashelp library in order to replace the data set. 


Zip Archive Contents
--------------------

ReadMe.txt .............. This text file.
zipcode_MONYY_v9.cpt .... The SAS transport file containing the updated data sets for Zipcode, Zipmil and Zipmisc. 
                          The file is named according to the date on which it was created, where MON is the 
                          three letter month name and YY is the two digit year. 
zipcode_replace.sas ..... A SAS program to replace your Zipcode and Zipmil data sets.
zipcode_combine.sas ..... A SAS program to combine the Zipcode, Zipmil, and Zipmisc data sets and replace the existing Zipcode data set.       


Instructions
------------

To programmically update the Zipcode and Zipmil data sets, run either the zipcode_replace.sas file or the 
zipcode_combine.sas file, specifying the path to your transport file in the macro call.


To manually update the Zipcode and Zipmil data sets, follow the steps below:

1) Use the CIMPORT procedure to import the zipcode_MONYY_v9.cpt file into the Sashelp library.

For example:

    proc cimport file='PATH/zipcode_MONYY_v9.cpt' lib=sashelp;
    run;

Note: You need to replace PATH with the directory name that contains your transport file and 
replace MONYY with the three letter month name and two digit year that corresponds to the 
transport file name.


2) Use the DATASETS procedure to delete the existing Zipcode data set from the Sashelp library.
   Rename the new Zipcode data set from the unique name to Zipcode. 

For example:

   proc datasets lib=sashelp nolist;
     delete zipcode;
   run;
     change zipcode_yyQq=zipcode;
   run;
   quit;

Note: You need to replace zipcode_yyQq in the CHANGE statement above to reflect the name of the data set that is created from the transport file. 
The data set is named in the form: Zipcode_yyQq, where yy is the two-digit year and q is the quarter in which the data set was created.


3) Use the DATASETS procedure to delete the existing Zipmil data set from the Sashelp library.
   Rename the new Zipmil data set from the unique name to Zipmil. 

For example:

   proc datasets lib=sashelp nolist;
     delete zipmil;
   run;
     change zipmil_yyQq=zipmil;
   run;
   quit;

Note: You need to replace zipmil_yyQq in the CHANGE statement above to reflect the name of the data set that is created from the transport file. 
The data set is named in the form: Zipmil_yyQq, where yy is the two-digit year and q is the quarter in which the data set was created.


Additional Resources
--------------------

For more information on replacing the SASHELP.ZIPCODE data set, refer to SAS Note:
   http://support.sas.com/techsup/notes/v8/19861

For more information on concatenating a directory with the SASHELP library, refer to SAS Note:
   http://support.sas.com/kb/42362

For more information on PROC CIMPORT, refer to the SAS documentation at:
   http://support.sas.com/documentation

For assistance with the SAS System, please contact SAS Technical Support:
   https://www.sas.com/en_us/contact/technical-support.html

